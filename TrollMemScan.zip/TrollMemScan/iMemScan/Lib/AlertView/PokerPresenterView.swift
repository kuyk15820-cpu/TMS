//
//  PokerPresenterView.swift
//  PokerCard
//
//  Created by Weslie on 2019/9/16.
//  Copyright © 2019 Weslie (https://www.iweslie.com)
//
//  Permission is hereby granted, free of charge, to any person obtaining a copy
//  of this software and associated documentation files (the "Software"), to deal
//  in the Software without restriction, including without limitation the rights
//  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
//  copies of the Software, and to permit persons to whom the Software is
//  furnished to do so, subject to the following conditions:
//
//  The above copyright notice and this permission notice shall be included in
//  all copies or substantial portions of the Software.
//
//  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
//  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
//  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
//  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
//  THE SOFTWARE.
//

import UIKit

/// A background container view for presented PokerView.
internal class PokerPresenterView: UIView, UIGestureRecognizerDelegate {
    
    internal var pokerView: PokerView? {
        didSet {
            guard let pokerView = pokerView else { return }
            
            addSubview(pokerView)
            
            pokerView.constraint(alignCenter: self)
            
            // tap background to dismiss
            let tap = UITapGestureRecognizer(target: pokerView, action: #selector(pokerView.dismiss))
            tap.delegate = self
            
            // move to center with animation
            pokerView.center = CGPoint(x: frame.width / 2, y: frame.height + 50)
            pokerView.alpha = 0
            UIView.animate(withDuration: 0.25) { pokerView.alpha = 1 }
            UIView.animate(withDuration: 0.65, delay: 0, usingSpringWithDamping: 0.8, initialSpringVelocity: 18, options: [], animations: {
                pokerView.center = self.center
            }) { _ in
                self.addGestureRecognizer(tap)
            }
        }
    }

    override init(frame: CGRect) {
        super.init(frame: frame)
        
        self.backgroundColor = PKColor.clear
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldReceive touch: UITouch) -> Bool {
        // disbale tap gesture in superview
        let hitPoint = touch.location(in: self)
        if let pokerFrame = pokerView?.frame, pokerFrame.contains(hitPoint) {
            return false
        }
        return true
    }

}
